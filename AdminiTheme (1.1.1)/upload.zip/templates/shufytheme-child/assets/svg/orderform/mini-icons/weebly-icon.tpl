<svg class="marketconnect__illustrations__icons homepage__promo__slider__nav__box__icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
    <g id="select-back--behind-box-design-layer-layers-select-send-to-back">
        <path id="Vector" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M3.5 9.5c0 0.26522 0.10536 0.5196 0.29289 0.7071 0.18754 0.1875 0.44189 0.2929 0.70711 0.2929" stroke-width="1"></path>
        <path id="Vector_2" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M4.5 0.5c-0.26522 0 -0.51957 0.105357 -0.70711 0.292893C3.60536 0.98043 3.5 1.23478 3.5 1.5" stroke-width="1"></path>
        <path id="Vector_3" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M13.5 1.5c0 -0.26522 -0.1054 -0.51957 -0.2929 -0.707107C13.0196 0.605357 12.7652 0.5 12.5 0.5" stroke-width="1"></path>
        <path id="Vector_4" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M12.5 10.5c0.2652 0 0.5196 -0.1054 0.7071 -0.2929S13.5 9.76522 13.5 9.5" stroke-width="1"></path>
        <path id="Vector_5" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M10.5 13.5h-8c-0.53043 0 -1.03914 -0.2107 -1.41421 -0.5858C0.710714 12.5391 0.5 12.0304 0.5 11.5v-8" stroke-width="1"></path>
        <path id="Vector_6" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M7.5 0.5h2" stroke-width="1"></path>
        <path id="Vector_7" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M7.5 10.5h2" stroke-width="1"></path>
        <path id="Vector_8" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5v2" stroke-width="1"></path>
        <path id="Vector_9" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M3.5 4.5v2" stroke-width="1"></path>
    </g>
</svg>
