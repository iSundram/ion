<svg class="marketconnect__illustrations__icons homepage__promo__slider__nav__box__icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
    <g id="application-search--application-new-search-square">
        <path
            id="Vector"
            class="primary-color"
            d="M4.59091 0.5H1.40909C0.907014 0.5 0.5 0.907014 0.5 1.40909v3.18182c0 0.50208 0.407014 0.90909 0.90909 0.90909h3.18182c0.50208 0 0.90909 -0.40701 0.90909 -0.90909V1.40909C5.5 0.907014 5.09299 0.5 4.59091 0.5Z"
            stroke-width="1"
        ></path>
        <path
            id="Vector_2"
            class="secondary-color-stroke"
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M4.59091 0.5H1.40909C0.907014 0.5 0.5 0.907014 0.5 1.40909v3.18182c0 0.50208 0.407014 0.90909 0.90909 0.90909h3.18182c0.50208 0 0.90909 -0.40701 0.90909 -0.90909V1.40909C5.5 0.907014 5.09299 0.5 4.59091 0.5Z"
            stroke-width="1"
        ></path>
        <path
            id="Vector_3"
            class="primary-color"
            d="M11.5909 0.5H8.40909C7.90701 0.5 7.5 0.907014 7.5 1.40909v3.18182c0 0.50208 0.40701 0.90909 0.90909 0.90909h3.18181c0.5021 0 0.9091 -0.40701 0.9091 -0.90909V1.40909C12.5 0.907014 12.093 0.5 11.5909 0.5Z"
            stroke-width="1"
        ></path>
        <path
            id="Vector_4"
            class="secondary-color-stroke"
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M11.5909 0.5H8.40909C7.90701 0.5 7.5 0.907014 7.5 1.40909v3.18182c0 0.50208 0.40701 0.90909 0.90909 0.90909h3.18181c0.5021 0 0.9091 -0.40701 0.9091 -0.90909V1.40909C12.5 0.907014 12.093 0.5 11.5909 0.5Z"
            stroke-width="1"
        ></path>
        <path
            id="Vector_5"
            class="primary-color"
            d="M4.59091 7.5H1.40909C0.907014 7.5 0.5 7.90701 0.5 8.40909v3.18181c0 0.5021 0.407014 0.9091 0.90909 0.9091h3.18182c0.50208 0 0.90909 -0.407 0.90909 -0.9091V8.40909C5.5 7.90701 5.09299 7.5 4.59091 7.5Z"
            stroke-width="1"
        ></path>
        <path
            id="Vector_6"
            class="secondary-color-stroke"
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M4.59091 7.5H1.40909C0.907014 7.5 0.5 7.90701 0.5 8.40909v3.18181c0 0.5021 0.407014 0.9091 0.90909 0.9091h3.18182c0.50208 0 0.90909 -0.407 0.90909 -0.9091V8.40909C5.5 7.90701 5.09299 7.5 4.59091 7.5Z"
            stroke-width="1"
        ></path>
        <path id="vector" class="bg-color" d="M10.25 13c1.5188 0 2.75 -1.2312 2.75 -2.75 0 -1.51878 -1.2312 -2.75 -2.75 -2.75 -1.51878 0 -2.75 1.23122 -2.75 2.75 0 1.5188 1.23122 2.75 2.75 2.75Z" stroke-width="1"></path>
        <path
            id="vector_2"
            class="secondary-color-stroke"
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M10.25 13c1.5188 0 2.75 -1.2312 2.75 -2.75 0 -1.51878 -1.2312 -2.75 -2.75 -2.75 -1.51878 0 -2.75 1.23122 -2.75 2.75 0 1.5188 1.23122 2.75 2.75 2.75Z"
            stroke-width="1"
        ></path>
        <path id="vector_3" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="m13.5002 13.5 -1.3056 -1.3056" stroke-width="1"></path>
    </g>
</svg>
