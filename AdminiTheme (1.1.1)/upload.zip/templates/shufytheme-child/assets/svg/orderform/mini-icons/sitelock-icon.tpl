<svg class="marketconnect__illustrations__icons homepage__promo__slider__nav__box__icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
    <g id="padlock-shield--combination-combo-lock-locked-padlock-secure-security-shield">
        <path id="Vector 3821" class="primary-color" d="M12 1H2c-0.55228 0 -1 0.44772 -1 1v2.67544C1 8.45241 3.41686 11.8056 7 13c3.5831 -1.1944 6 -4.54759 6 -8.32456V2c0 -0.55228 -0.4477 -1 -1 -1Z" stroke-width="1"></path>
        <path id="Vector 3823" class="bg-color" d="M4.5 9V6.5c0 -0.27614 0.22386 -0.5 0.5 -0.5h4c0.27614 0 0.5 0.22386 0.5 0.5V9c0 0.27614 -0.22386 0.5 -0.5 0.5H5c-0.27614 0 -0.5 -0.22386 -0.5 -0.5Z" stroke-width="1"></path>
        <path
            id="Vector 3822"
            class="secondary-color-stroke"
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M12 1H2c-0.55228 0 -1 0.44772 -1 1v2.67544C1 8.45241 3.41686 11.8056 7 13c3.5831 -1.1944 6 -4.54759 6 -8.32456V2c0 -0.55228 -0.4477 -1 -1 -1Z"
            stroke-width="1"
        ></path>
        <path
            id="Vector 3825"
            class="secondary-color-stroke"
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M4.5 9V6.5c0 -0.27614 0.22386 -0.5 0.5 -0.5h4c0.27614 0 0.5 0.22386 0.5 0.5V9c0 0.27614 -0.22386 0.5 -0.5 0.5H5c-0.27614 0 -0.5 -0.22386 -0.5 -0.5Z"
            stroke-width="1"
        ></path>
        <path id="Vector 3824" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M5.25 6V4.75C5.25 3.7835 6.0335 3 7 3v0c0.9665 0 1.75 0.7835 1.75 1.75V6" stroke-width="1"></path>
    </g>
</svg>
