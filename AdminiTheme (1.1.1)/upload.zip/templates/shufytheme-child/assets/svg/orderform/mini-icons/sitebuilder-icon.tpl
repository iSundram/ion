<svg class="marketconnect__illustrations__icons homepage__promo__slider__nav__box__icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
    <g id="cursor-area-selection-1--mouse-select-cursor-area-selection">
        <path
            id="Vector"
            class="primary-color"
            d="M13.2337 9.15353c0.0841 -0.03504 0.1384 -0.05061 0.1883 -0.10051s0.078 -0.11757 0.078 -0.18814c0 -0.07057 -0.0281 -0.13825 -0.078 -0.18815s-0.0668 -0.0798 -0.1883 -0.11543c-0.1215 -0.03564 -6.02863 -2.03261 -6.02863 -2.03261 -0.09426 -0.03225 -0.19569 -0.03743 -0.29276 -0.01495 -0.09706 0.02249 -0.18587 0.07173 -0.25633 0.14213 -0.07045 0.0704 -0.11973 0.15914 -0.14223 0.25613 -0.02249 0.09699 -0.01731 0.19834 0.01496 0.29254 0 0 2.04421 5.94856 2.06918 6.02936 0.02497 0.0809 0.05719 0.1383 0.10712 0.1882 0.04994 0.0499 0.11767 0.0779 0.1883 0.0779 0.07062 0 0.13835 -0.028 0.18829 -0.0779 0.04993 -0.0499 0.06135 -0.0782 0.09878 -0.1882 0.03744 -0.11 1.04432 -3.012 1.04432 -3.012s2.925 -1.03333 3.009 -1.06837Z"
            stroke-width="1"
        ></path>
        <path
            id="Vector_2"
            class="secondary-color-stroke"
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M13.2337 9.15353c0.0841 -0.03504 0.1384 -0.05061 0.1883 -0.10051 0.0499 -0.04989 0.078 -0.11757 0.078 -0.18814 0 -0.07057 -0.0281 -0.13825 -0.078 -0.18815s-0.0668 -0.0798 -0.1883 -0.11543c-0.1215 -0.03564 -6.02863 -2.03261 -6.02863 -2.03261 -0.09426 -0.03225 -0.19569 -0.03743 -0.29276 -0.01495 -0.09706 0.02249 -0.18587 0.07173 -0.25633 0.14213 -0.07045 0.0704 -0.11973 0.15914 -0.14223 0.25613 -0.02249 0.09699 -0.01731 0.19834 0.01496 0.29254 0 0 2.04421 5.94856 2.06918 6.02936 0.02497 0.0809 0.05719 0.1383 0.10712 0.1882 0.04994 0.0499 0.11767 0.0779 0.1883 0.0779 0.07062 0 0.13835 -0.028 0.18829 -0.0779 0.04993 -0.0499 0.06135 -0.0782 0.09878 -0.1882 0.03744 -0.11 1.04432 -3.012 1.04432 -3.012s2.925 -1.03333 3.009 -1.06837Z"
            stroke-width="1"
        ></path>
        <path id="Vector_3" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M0.5 9.5c0 0.26522 0.105357 0.5196 0.292893 0.7071 0.187537 0.1875 0.441887 0.2929 0.707107 0.2929" stroke-width="1"></path>
        <path id="Vector_4" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M1.5 0.5C1.23478 0.5 0.98043 0.605357 0.792893 0.792893 0.605357 0.98043 0.5 1.23478 0.5 1.5" stroke-width="1"></path>
        <path id="Vector_5" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M10.5 1.5c0 -0.26522 -0.1054 -0.51957 -0.2929 -0.707107C10.0196 0.605357 9.76522 0.5 9.5 0.5" stroke-width="1"></path>
        <path id="Vector_6" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M4.5 0.5h2" stroke-width="1"></path>
        <path id="Vector_7" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M4.5 10.5H5" stroke-width="1"></path>
        <path id="Vector_8" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M10.5 4.5V5" stroke-width="1"></path>
        <path id="Vector_9" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M0.5 4.5v2" stroke-width="1"></path>
    </g>
</svg>
