<svg class="marketconnect__illustrations__icons homepage__promo__slider__nav__box__icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
    <g id="VPN-connection">
        <path id="Vector 3701" class="primary-color" d="M12 1H2c-0.55228 0 -1 0.44772 -1 1v2.67544C1 8.45241 3.41686 11.8056 7 13c3.5831 -1.1944 6 -4.54759 6 -8.32456V2c0 -0.55228 -0.4477 -1 -1 -1Z" stroke-width="1"></path>
        <path
            id="Vector 3702"
            class="secondary-color-stroke"
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M12 1H2c-0.55228 0 -1 0.44772 -1 1v2.87355c0 3.65866 2.34116 6.90685 5.81206 8.06385L7 13l0.18794 -0.0626C10.6588 11.7804 13 8.53221 13 4.87355V2c0 -0.55228 -0.4477 -1 -1 -1Z"
            stroke-width="1"
        ></path>
        <path id="Vector 524" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M3.2832 5.07554c0.46429 -0.30952 1.85715 -0.92857 3.71429 -0.92857s3.25001 0.61905 3.71431 0.92857" stroke-width="1"></path>
        <path id="Vector 525" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M4.63037 7.0627c0.39451 -0.19725 1.42022 -0.59175 2.36703 -0.59175 0.94681 0 1.97252 0.3945 2.36703 0.59175" stroke-width="1"></path>
        <path id="Vector 526" class="secondary-color-stroke" stroke-linecap="round" stroke-linejoin="round" d="M6.22217 9.07893c0.1292 -0.0646 0.46511 -0.1938 0.77519 -0.1938s0.64599 0.1292 0.77519 0.1938" stroke-width="1"></path>
    </g>
</svg>
