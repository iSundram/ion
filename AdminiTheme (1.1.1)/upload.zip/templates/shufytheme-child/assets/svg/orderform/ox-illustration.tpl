<svg class="promo__slider__illunsration" xmlns="http://www.w3.org/2000/svg" viewBox="186.5 126.09 777.6 898.81">
    <g fill="none" fill-rule="evenodd">
        <g transform="translate(186 126)">
            <path class="st6 animated__shapes shape__one" fill-rule="nonzero" d="M331.2,2.2 L778.1,502.1 L331.1,486.1 C327.8,486 324.2,480.6 325,477 L370,277.2 L595.2,390 L367.3,241.1 L325.1,4.4 C324.3,-0.2 327.9,-1.4 331.2,2.2 Z" opacity=".07"/>
            <path class="st3 animated__shapes shape__one" fill-rule="nonzero" d="M296.9,27.1 L743.8,527 L296.8,511 C293.5,510.9 289.9,505.5 290.7,501.9 L335.6,302.2 L560.8,415 L333.1,266 L290.8,29.3 C290,24.7 293.6,23.5 296.9,27.1 Z"/>
            
			
			<polygon class="st0 animated__shapes shape__two" fill-rule="nonzero" points="329.8 555.2 32.2 383.4 32.3 538.5 303.6 695.1 329.9 734"/>
            <polygon class="st2 animated__shapes shape__five" points=".5 443.9 .5 401.8 112.8 466.6 112.8 508.7"/>
            <polygon class="st1 animated__shapes shape__two" fill-rule="nonzero" points="253.3 548.8 188.1 511.2 188.1 524.8 253.3 562.4"/>
            <polygon class="st1 animated__shapes shape__two" fill-rule="nonzero" points="253.3 576 127.6 503.5 127.6 517.1 253.3 589.6"/>
            <polygon class="st1 animated__shapes shape__two" fill-rule="nonzero" points="253.4 603.3 101.1 515.4 101.1 529 253.4 616.9"/>
            <path class="st2 animated__shapes shape__two" d="M269.4,572.2 C269.4,585 277,599.7 286.3,605.1 C295.6,610.5 303.2,604.5 303.2,591.7 C303.2,578.9 295.6,564.2 286.3,558.8 C276.9,553.4 269.4,559.4 269.4,572.2 Z"/>
            
			<polygon class="st0 animated__shapes shape__three" fill-rule="nonzero" points="355.5 427.1 653.1 598.9 653.2 754 381.8 597.3 355.6 605.9"/>
            <polygon class="st2 animated__shapes shape__five"  points="566.5 626.2 566.5 584.1 678.8 648.9 678.8 691"/>
            <polygon class="st1 animated__shapes shape__three" fill-rule="nonzero" points="432 509 497.2 546.6 497.2 560.2 432 522.6"/>
            <polygon class="st1 animated__shapes shape__three" fill-rule="nonzero" points="432 536.3 549.7 604.2 549.7 617.8 432 549.9"/>
            <polygon class="st1 animated__shapes shape__three" fill-rule="nonzero" points="432.1 563.5 584.4 651.4 584.4 665 432.1 577.1"/>
            <path class="st2 animated__shapes shape__three" d="M416,513.9 C416,526.7 408.4,532.7 399.1,527.3 C389.8,521.9 382.2,507.2 382.2,494.4 C382.2,481.6 389.8,475.6 399.1,481 C408.4,486.4 416,501.2 416,513.9 Z"/>
            
			<polygon class="st0 animated__shapes shape__four" fill-rule="nonzero" points="693.8 806.3 516.1 703.7 516.1 796.3 693.8 898.9"/>
            <polygon class="st1 animated__shapes shape__four" fill-rule="nonzero" points="561.6 752.3 615 783.2 615 794.3 561.6 763.4"/>
            <polygon class="st1 animated__shapes shape__four" fill-rule="nonzero" points="561.6 774.6 675.4 840.3 675.4 851.6 561.6 785.9"/>
            <path class="st2 animated__shapes shape__four" d="M552.2,755.6 C552.2,763.2 547.7,766.8 542.1,763.6 C536.5,760.4 532,751.6 532,744 C532,736.4 536.5,732.8 542.1,736 C547.7,739.2 552.2,748 552.2,755.6 Z"/>
            
			<polygon class="st0 animated__shapes shape__four" fill-rule="nonzero" points="201.8 664.3 24.1 561.7 24.1 654.3 201.8 756.9"/>
            <polygon class="st1 animated__shapes shape__four" fill-rule="nonzero" points="69.6 610.3 123 641.2 123 652.3 69.6 621.4"/>
            <polygon class="st1 animated__shapes shape__four" fill-rule="nonzero" points="69.6 632.6 183.4 698.3 183.4 709.6 69.6 643.9"/>
           
		   <path class="st2 animated__shapes shape__five" d="M60.2,613.6 C60.2,621.2 55.7,624.8 50.1,621.6 C44.5,618.4 40,609.6 40,602 C40,594.4 44.5,590.8 50.1,594 C55.7,597.2 60.2,606 60.2,613.6 Z"/>
            <path class="st0 animated__shapes shape__five" fill-rule="nonzero" d="M227.3,369.8 L184.5,345.1 L184.5,330.7 L227.3,355.4 C230.8,357.4 235.9,361.5 240.2,367.8 C244.9,374.5 248.2,383 248.2,392.2 C248.2,402.4 245.6,408.2 240.7,409.8 C236.1,411.3 230.6,408.7 227.3,406.8 L209.7,396.6 L209.6,396.5 C208.1,395.6 205.7,394.7 203.8,395.3 C202.2,395.8 200.5,397.3 200.5,403 C200.5,408.7 202.3,412.1 203.7,414.2 C205.5,416.8 207.9,418.6 209.4,419.4 L209.6,419.5 L263.4,450.6 L263.4,465 L209.9,434.1 C206.2,432.2 200.9,428.1 196.3,421.7 C191.3,414.6 187.9,405.7 187.9,395.8 C187.9,385.9 191.3,380.9 196.2,379.5 C200.8,378.2 206.1,380.1 209.8,382.3 L227.2,392.3 C229.7,393.8 231.6,394.4 232.9,394 C233.9,393.7 235.7,392.3 235.7,385 C235.7,380.2 234.2,377.1 232.7,375.1 C231,372.5 228.7,370.6 227.3,369.8 Z"/>
            <path class="st2 animated__shapes shape__five" d="M192.3,342 C192.3,354.9 184.7,361 175.4,355.7 C166.1,350.3 158.5,335.5 158.5,322.5 C158.5,309.6 166.1,303.5 175.4,308.8 C184.7,314.2 192.3,329.1 192.3,342 Z"/>
            
			<path class="st2 animated__shapes shape__five" d="M285.3,470 C285.3,482.9 277.7,489 268.4,483.7 C259.1,478.3 251.5,463.5 251.5,450.5 C251.5,437.6 259.1,431.5 268.4,436.8 C277.7,442.2 285.3,457.1 285.3,470 Z"/>
            <path class="st0 animated__shapes shape__five" fill-rule="nonzero" d="M404.1,676.7 L404.1,761 C404.1,761.9 405,762.9 405.6,762.6 L425.3,750.5 L445.4,786.1 C446.5,788 448.4,788.2 448.4,786.4 L448.4,702.4 L404.1,676.7 Z"/>
        </g>
    </g>
</svg>